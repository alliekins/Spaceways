IT IS THE FUTURE. Humanity has expanded to a few scattered planets, but with all the "boldly going where no man has gone before", they kind of forgot to set up a package shipping system. UNTIL NOW.

You, the shrewd businessman or woman, has seen this gap as the business opporrunity it is. You have withdrawn your life savings of $5,000 and are ready to start building processing centers "SpaceHubs" and purchasing ships to run your routes to make your fortune. Good luck, INTREPID SMALL BUSINESS OWNER!

HOW TO PLAY: Click on planets to build hubs. Once you have two or more hubs, you can buy ships to run routes between them by clicking the line that connects two hubs. Red lines are routes you are servicing right now.

NOTES:
Packages don't seem to always deduct from the hub properly when they are loaded on ships. 
Graphics are obviously not final AT ALL.
